import { ADD_ARTICLE } from "../constants/action-types";
const initialState = {
  articles: 0
};
const rootReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_ARTICLE:
      return { ...state, articles: state.articles + 1 };
    default:
      return state;
  }
};
export default rootReducer;
